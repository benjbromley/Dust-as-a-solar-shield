

Mdust = 1e12
Mduststr = r'$10^{9}$ kg'
attnlevel = 0.018
